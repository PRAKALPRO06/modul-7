package main

import (
	"fmt"
	"math"
)

func main() {
	var n, x, delIndex, target int
	fmt.Print("Masukkan jumlah elemen array (N): ")
	fmt.Scan(&n)

	// Inisialisasi array
	array := make([]int, n)
	fmt.Println("Masukkan elemen-elemen array:")
	for i := 0; i < n; i++ {
		fmt.Printf("Elemen ke-%d: ", i)
		fmt.Scan(&array[i])
	}

	// a. Menampilkan keseluruhan isi array
	fmt.Println("Isi array:", array)

	// b. Menampilkan elemen dengan indeks ganjil
	fmt.Println("Elemen dengan indeks ganjil:")
	for i := 1; i < n; i += 2 {
		fmt.Printf("Index %d: %d\n", i, array[i])
	}

	// c. Menampilkan elemen dengan indeks genap
	fmt.Println("Elemen dengan indeks genap:")
	for i := 0; i < n; i += 2 {
		fmt.Printf("Index %d: %d\n", i, array[i])
	}

	// d. Menampilkan elemen dengan indeks kelipatan bilangan x
	fmt.Print("Masukkan nilai x untuk kelipatan indeks: ")
	fmt.Scan(&x)
	fmt.Println("Elemen dengan indeks kelipatan", x, ":")
	for i := 0; i < n; i++ {
		if i%x == 0 {
			fmt.Printf("Index %d: %d\n", i, array[i])
		}
	}

	// e. Menghapus elemen pada indeks tertentu
	fmt.Print("Masukkan indeks yang akan dihapus: ")
	fmt.Scan(&delIndex)
	array = append(array[:delIndex], array[delIndex+1:]...)
	fmt.Println("Isi array setelah penghapusan:", array)

	// f. Menampilkan rata-rata bilangan dalam array
	sum := 0
	for _, v := range array {
		sum += v
	}
	rataRata := float64(sum) / float64(len(array))
	fmt.Printf("Rata-rata elemen array: %.2f\n", rataRata)

	// g. Menampilkan standar deviasi
	var varianceSum float64
	for _, v := range array {
		varianceSum += math.Pow(float64(v)-rataRata, 2)
	}
	stdDeviasi := math.Sqrt(varianceSum / float64(len(array)))
	fmt.Printf("Standar deviasi elemen array: %.2f\n", stdDeviasi)

	// h. Menampilkan frekuensi suatu bilangan
	fmt.Print("Masukkan bilangan untuk mengetahui frekuensinya: ")
	fmt.Scan(&target)
	count := 0
	for _, v := range array {
		if v == target {
			count++
		}
	}
	fmt.Printf("Frekuensi bilangan %d dalam array: %d\n", target, count)
}
