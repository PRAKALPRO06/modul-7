package main

import (
	"fmt"
)

func main() {
	var klubA, klubB string
	var skorA, skorB int
	var pemenang []string

	// Input nama klub
	fmt.Print("Klub A: ")
	fmt.Scanln(&klubA)
	fmt.Print("Klub B: ")
	fmt.Scanln(&klubB)

	// Proses input skor pertandingan
	pertandingan := 1
	for {
		fmt.Printf("Pertandingan %d: ", pertandingan)
		fmt.Scan(&skorA, &skorB)

		// Validasi skor
		if skorA < 0 || skorB < 0 {
			break
		}

		// Menentukan pemenang
		if skorA > skorB {
			fmt.Printf("Hasil %d: %s\n", pertandingan, klubA)
			pemenang = append(pemenang, klubA)
		} else if skorA < skorB {
			fmt.Printf("Hasil %d: %s\n", pertandingan, klubB)
			pemenang = append(pemenang, klubB)
		} else {
			fmt.Printf("Hasil %d: Draw\n", pertandingan)
		}

		pertandingan++
	}

	fmt.Println("Pertandingan selesai")

	// Menampilkan daftar klub pemenang
	fmt.Println("Daftar klub yang memenangkan pertandingan:")
	for _, klub := range pemenang {
		fmt.Println(klub)
	}
}
